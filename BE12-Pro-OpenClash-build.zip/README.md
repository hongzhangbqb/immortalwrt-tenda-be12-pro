# 腾达 BE12 Pro · 10 月 26 日版 OpenClash 定制构建

基准为 Sun-flower1 的 `2026.10.26-214409-13`。交付的是可放入其 fork 的完整构建文件。已校验两份原版镜像、读取原镜像内的软件源和包数据库，并用原镜像实测布局检查程序。定制固件尚未完成 Linux 编译、上机启动或无线/加速实测。核对日期为 2026-10-31。

## 在自己的 GitHub fork 构建

1. Fork `Sun-flower1/immortalwrt-tenda-be12-pro`。下载本构建包后，在有 Git 的电脑上执行以下命令。把第一、二行改成自己的 fork 地址和 ZIP 文件的绝对路径。

   ```sh
   FORK_URL='https://github.com/你的账号/immortalwrt-tenda-be12-pro.git'
   KIT='/你的下载目录/BE12-Pro-OpenClash-build.zip'
   git clone "$FORK_URL" be12-pro-custom && cd be12-pro-custom
   git switch -c be12-openclash e16c403e2fc00ad3fc1392dc11e0c60e5b548d42
   unzip -o "$KIT"
   git add -f .config
   git add .github/workflows/openwrt-builder.yml diy.sh feeds.conf.default build baseline README.md
   git diff --cached --stat
   git commit -m "Build BE12 Pro October baseline with OpenClash 0.48.002"
   git push -u origin be12-openclash
   ```

2. 在自己的 fork 将 `be12-openclash` 设为默认分支，或把该分支合并到默认分支。在 Actions 启用工作流，选择 **BE12 Pro OpenClash → Run workflow**，选定含本改动的分支。该工作流只手动运行，仅需仓库读取权限。
3. 全部通过后，在此次运行的 **Artifacts** 下载 `be12-pro-openclash-0.48.002-运行编号` 并解压。里面应有 sysupgrade、initramfs-kernel、`SHA256SUMS`、实际包差异、完整配置、feed 锁、构建提交、镜像布局和核心版本。在解压目录验证：

   ```sh
   # Linux
   sha256sum -c SHA256SUMS
   # macOS
   shasum -a 256 -c SHA256SUMS
   ```

   两项均须为 OK。任一配置、依赖、镜像或校验检查失败，工作流会在上传前停止。编译失败可查看单线程详细日志；若提示版本或包差异，先核对日志中的包名和版本。

## 原版依据与定制范围

| 项目 | 已核实的值 |
|---|---|
| 原构建 | GitHub Actions 运行 40295756107，第 13 次，Release 标签和工作流均指向 `e16c403e2fc00ad3fc1392dc11e0c60e5b548d42` |
| 固件源码 | chasey-dev 的 `25.12-dev-wifi7`，`4ab9dab8f909e9b3499e35d89b32d14ee1da80c5`。原镜像写入 `r1-4ab9dab8f`，与当次上游缓存一致。10 月 31 日查询分支仍在该提交 |
| 配置基底 | `defconfig/low-mem-512m/mt7987-mt7992-be7200.config`，保留原 diy.sh 的 post 阶段和单机型目标。原版去除的 Routerich 目标、UPnP 和 Easy QoS 沿用原处理。管理地址仍为 `192.168.3.1` |
| 软件源 | 从原 sysupgrade 的 `/etc/build.feeds` 提取。保留的 packages、luci、routing、telephony、video 五个完整 SHA 在 `feeds.conf.default`；含两个 PassWall 源的原始七项在 `baseline/orig-build.feeds` |
| 设备与软件 | `mediatek/filogic`、`tenda,be12-pro`、MT7987A + MT7992；原包架构 `aarch64_cortex-a53`，内核 6.12.112。原镜像使用 APK、firewall4、dnsmasq-full |
| OpenClash | 官方最新非预发行 Release `v0.48.002` 发布于 10 月 12 日，标签指向 `e553e82e01c697aefbe1555261a503f425e00ccd`。官方发布 APK 和 IPK；该基底对应 APK。官方文档给出的安装方式为 LuCI 上传或由对应包管理器安装，再配置核心和订阅 |
| 软件包实现 | 锁定的 ImmortalWrt LuCI feed 自带同版本打包配方，声明 Firewall4 所需依赖。工作流将应用的 `root`、`luasrc` 和中文 `po` 完整同步到官方标签版本，保留该分支配方，显式声明编译中文资源所需的 `luci-base/host`。配置检查涵盖 Ruby/YAML、TUN、nft-tproxy、inet-diag、dnsmasq nftset、luci-compat 等 |
| 代理核心 | 按官方更新脚本的 master/meta 路径，内置 OpenClash core 仓分支提交 `70e44a6f730a11730a1daa6b0a71a7634c87fe68` 的 Linux ARM64 Meta 核心。已核实压缩包 SHA-256 为 `aae510c46001b8784b1480be94c3c740db9b387e5419604abaafa4189cd99c6d`，解压是静态 AArch64 ELF。CI 还会对成品内的核心验哈希并用 QEMU 执行 `-v` |
| 软件清单 | 与原 ROM 实际安装的 356 个包逐项对照。移除 PassWall2、其中文包、Xray 和专用客户端/数据包；依赖由 defconfig 重新选择。保留原基底显式需要的 ipset、resolveip 和与 OpenClash 共享的依赖。检查保留包的版本，仅容许同一内核版本的 ABI 后缀变化；新增包须能从 OpenClash/运行依赖到达 |
| 保留项 | LuCI、简体中文（含无线和 TurboACC）、Argon、MTK 闭源 mt_wifi7、mt_hwifi、MT7992、11be、WARP、HNAT、TurboACC 和以太网 PHY 包。构建时与原 ROM 的硬件配置、无线 profile、升级脚本及默认网络配置生成器对照。这是保留加速支持；代理转发流量能否被加速需在具体模式下实测 |

原镜像从 Release 下载后实际计算的 SHA-256：

| 10 月 26 日原版文件 | 字节 | SHA-256 |
|---|---:|---|
| `*squashfs-sysupgrade.bin` | 45,906,194 | `726e0796db159299070e7a4eb7a79d1af4794bc197e5b5ed7aa077f148e01d6b` |
| `*initramfs-kernel.bin` | 38,273,024 | `4b75acf0329c26817e265c59833476d57a10103389323a28fae113b94162c11b` |

定制产物的哈希以其成功运行随附的 `SHA256SUMS` 为准。固件源码、feed、OpenClash 程序与核心、Actions 插件都锁定到提交。GitHub 托管 Ubuntu 的系统包和构建签名密钥未冻结，因此不承诺跨运行二进制逐字节一致。

## 镜像与实机检查

原版 sysupgrade 的 tar 只包含 `CONTROL`、`kernel`、`root` 三个文件。内核先是腾达 `God1` 双镜像头，后接 ARM64 FIT；原内核成员 4,637,248 字节，SquashFS 根文件系统成员 41,263,104 字节。另一份 initramfs 是带 ramdisk 的独立 FIT。两份镜像的内嵌设备树 SHA-256 均为 `c40b274d9c00e4f88e4b4f9bafc3a420416a338291bf9e1cafece30f0bb3f5d2`。工作流要求新镜像沿用同一设备树、板名、升级兼容版本 1.0、FIT 加载地址 0x40000000 和分区布局。

| SPI NAND 分区 | 起始偏移 | 容量 |
|---|---:|---:|
| Bootloader | 0x000000 | 3 MiB |
| u-boot-env | 0x300000 | 512 KiB |
| Factory（校准数据） | 0x380000 | 4 MiB |
| kernel | 0x780000 | 6 MiB |
| ubi | 0xd80000 | 90 MiB |
| CFG | 0x6780000 | 4 MiB |
| MISC2 | 0x6b80000 | 4 MiB |

源码布局使用 128 KiB 擦除块和 2 KiB 页。CI 要求整段带头内核能放入 6 MiB，压缩 rootfs 上限保守设为 80 MiB，给 UBI、坏块与可写层预留空间。实机的可用块、坏块和保留量仍要核对。

**已在运行 10 月 26 日 ImmortalWrt 的 BE12 Pro**：先将配置备份保存到电脑，备好已知可恢复的原版镜像及适用的恢复途径，使用有线连接。将构建产物中的 sysupgrade 和对应 `SHA256SUMS`、本包的 `build/check-router.sh` 复制到路由器 `/tmp`，确认内存空间充足。在路由器运行：

```sh
sh /tmp/check-router.sh \
  /tmp/immortalwrt-mediatek-filogic-tenda_be12-pro-squashfs-sysupgrade.bin \
  /tmp/SHA256SUMS
```

此脚本只读，检查已安装 ROM 修订和构建配置、板号、设备树、当前升级脚本、MTD 偏移/容量、NAND 几何、UBI 附着和实际容量，以及下载哈希，并调用 `sysupgrade -T`。它会打印 UBI 信息。若系统未提供分区偏移、容量或板号不符、平台检查失败，停在此处。即使返回成功也要检查异常坏块/容量与恢复条件。确认后可在 LuCI「系统 → 备份/升级」选择已核对的 **sysupgrade** 文件，取消保留旧配置，核对 LuCI 再次给出的检查结果后决定是否升级。旧 PassWall2、防火墙和 DNS 配置不应整包恢复。

**原厂系统、其他机型/硬件修订、未知引导器或不同分区布局**：该 Release 未提供 factory 镜像。不要把这两个文件直接上传到原厂升级页。initramfs 仅适用于已核实引导方式的 RAM 启动测试；如无针对实机的引导与恢复资料，请先停在机型/分区核对，不使用强制升级或裸写分区。

首次启动用 `192.168.3.1` 登录。先在 OpenClash 关闭状态核对中文 LuCI、Argon、2.4/5 GHz 无线、网口和 TurboACC；再在「服务 → OpenClash」导入自己的配置或订阅，选择 Meta 核心后启用。检查核心启动日志、DNS、直连与代理访问，再测经过路由的吞吐。固件不含订阅，规则或地理数据库是否需要下载取决于配置。

## 来源

- [10 月 26 日 Release](https://github.com/Sun-flower1/immortalwrt-tenda-be12-pro/releases/tag/2026.10.26-214409-13) · [成功构建记录](https://github.com/Sun-flower1/immortalwrt-tenda-be12-pro/actions/runs/40295756107) · [当次工作流与配置](https://github.com/Sun-flower1/immortalwrt-tenda-be12-pro/tree/e16c403e2fc00ad3fc1392dc11e0c60e5b548d42)
- [设备镜像配方](https://github.com/chasey-dev/immortalwrt-mt798x-rebase/blob/4ab9dab8f909e9b3499e35d89b32d14ee1da80c5/target/linux/mediatek/image/filogic-ext.mk) · [设备树与分区](https://github.com/chasey-dev/immortalwrt-mt798x-rebase/blob/4ab9dab8f909e9b3499e35d89b32d14ee1da80c5/target/linux/mediatek/dts-ext/mt7987a-tenda-be12-pro.dts)
- [OpenClash 官方发布](https://github.com/vernesong/OpenClash/releases/tag/v0.48.002) · [该标签的安装说明](https://github.com/vernesong/OpenClash/blob/e553e82e01c697aefbe1555261a503f425e00ccd/README.md) · [ImmortalWrt 分支的打包配方](https://github.com/immortalwrt/luci/blob/c84adb975e207ae8b14982191838ec6218d632cd/applications/luci-app-openclash/Makefile) · [锁定的核心目录](https://github.com/vernesong/OpenClash/tree/70e44a6f730a11730a1daa6b0a71a7634c87fe68/master/meta)
